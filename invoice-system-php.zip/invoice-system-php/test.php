<?php 
// creer un id de facture automatique 
// modele : date du jour/OT-id
// exemple 2022-03-22/OT-038
// generons une date avec l'objet date 

$date = date('Y-m-d')."-OT";
echo $date;


?>